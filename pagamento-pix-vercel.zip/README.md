# Página de Pagamento PIX - VizzionPay

Este projeto implementa uma página de pagamento de 5 centavos usando a API da VizzionPay. A solução consiste em um frontend React moderno e um backend Flask que faz a integração com a API.

## 🚀 Funcionalidades

- ✅ Formulário de pagamento com validação em tempo real
- ✅ Formatação automática de telefone e CPF/CNPJ
- ✅ Integração completa com a API VizzionPay
- ✅ Interface responsiva e moderna
- ✅ Tratamento de erros
- ✅ Valor fixo de R$ 0,05 (5 centavos)

## 📁 Estrutura do Projeto

```
├── pagamento-pix/          # Frontend React
│   ├── src/
│   │   ├── App.jsx         # Componente principal
│   │   ├── App.css         # Estilos
│   │   └── ...
│   ├── dist/               # Build de produção
│   └── package.json
│
├── backend-pagamento/      # Backend Flask
│   ├── src/
│   │   ├── main.py         # Servidor principal
│   │   ├── routes/
│   │   │   └── payment.py  # Rota de pagamento
│   │   └── static/         # Frontend buildado
│   ├── venv/               # Ambiente virtual Python
│   └── requirements.txt
│
└── README.md              # Este arquivo
```

## 🛠️ Tecnologias Utilizadas

### Frontend
- **React 18** - Framework JavaScript
- **Vite** - Build tool
- **Tailwind CSS** - Framework CSS
- **shadcn/ui** - Componentes UI
- **Lucide React** - Ícones

### Backend
- **Flask** - Framework Python
- **Flask-CORS** - Habilitação de CORS
- **Requests** - Cliente HTTP para API externa

## 📋 Pré-requisitos

- Node.js 18+ e npm/pnpm
- Python 3.11+
- Credenciais válidas da API VizzionPay

## 🚀 Como Executar

### Opção 1: Executar Separadamente (Desenvolvimento)

#### Backend (Terminal 1)
```bash
cd backend-pagamento
source venv/bin/activate  # Linux/Mac
# ou venv\Scripts\activate  # Windows
python src/main.py
```

#### Frontend (Terminal 2)
```bash
cd pagamento-pix
npm install  # ou pnpm install
npm run dev  # ou pnpm run dev
```

### Opção 2: Executar Integrado (Produção)

```bash
# 1. Build do frontend
cd pagamento-pix
npm run build

# 2. Copiar build para o backend
cp -r dist/* ../backend-pagamento/src/static/

# 3. Executar apenas o backend
cd ../backend-pagamento
source venv/bin/activate
python src/main.py
```

Acesse: http://localhost:5000

## 🔧 Configuração das Credenciais

As credenciais da API VizzionPay estão configuradas no arquivo `backend-pagamento/src/routes/payment.py`:

```python
VIZZION_PUBLIC_KEY = "luizaugustohetfeller_y389rh0u6458g7im"
VIZZION_SECRET_KEY = "qdzgq50prgtm6wotiruwr4ekqsuov4es48lm97byoz0ex48jxhavgv0g20l50z7r"
```

**⚠️ Importante**: Para usar em produção, mova essas credenciais para variáveis de ambiente por segurança.

## 🔄 Fluxo de Funcionamento

1. **Frontend**: Usuário preenche o formulário com seus dados
2. **Validação**: Campos são validados e formatados automaticamente
3. **Envio**: Dados são enviados para o backend via POST `/api/create-pix-payment`
4. **Backend**: Processa os dados e faz requisição para a API VizzionPay
5. **Resposta**: Retorna QR Code e código PIX para o frontend
6. **Exibição**: Usuário vê o QR Code e pode copiar o código PIX

## 📝 API Endpoints

### POST `/api/create-pix-payment`

Cria um pagamento PIX de 5 centavos.

**Request Body:**
```json
{
  "name": "João Silva",
  "email": "joao@email.com",
  "phone": "(11) 98765-4321",
  "document": "123.456.789-01",
  "amount": 0.05
}
```

**Response (Sucesso):**
```json
{
  "success": true,
  "transactionId": "uuid-da-transacao",
  "status": "PENDING",
  "pix": {
    "code": "codigo-pix-copia-e-cola",
    "image": "url-da-imagem-qr-code",
    "base64": "qr-code-em-base64"
  },
  "order": { "id": "id-do-pedido" },
  "fee": 0.01
}
```

**Response (Erro):**
```json
{
  "error": "Erro ao processar pagamento",
  "details": "Descrição do erro",
  "statusCode": 400
}
```

## 🐛 Resolução de Problemas

### Erro "You are not authorized to sell"

Este erro indica que as credenciais da API não têm permissão para criar transações. Possíveis soluções:

1. **Verificar conta VizzionPay**: Certifique-se de que a conta está ativada para vendas
2. **Ambiente de teste**: As credenciais podem estar em modo sandbox
3. **Configurações da conta**: Verifique se há configurações adicionais necessárias
4. **Contatar suporte**: Entre em contato com o suporte da VizzionPay

### Erro de CORS

Se houver problemas de CORS, verifique se o Flask-CORS está instalado e configurado:

```python
from flask_cors import CORS
CORS(app)
```

### Problemas de Build

Se o build do React falhar:

```bash
cd pagamento-pix
rm -rf node_modules
npm install
npm run build
```

## 📱 Responsividade

A aplicação é totalmente responsiva e funciona em:
- 📱 Dispositivos móveis
- 💻 Tablets
- 🖥️ Desktops

## 🔒 Segurança

- ✅ Validação de dados no frontend e backend
- ✅ Sanitização de inputs
- ✅ Headers de segurança configurados
- ✅ HTTPS recomendado para produção

## 📄 Licença

Este projeto foi desenvolvido para demonstração da integração com a API VizzionPay.

## 📞 Suporte

Para dúvidas sobre a API VizzionPay, consulte:
- 📧 Email: suporte@vizzionpay.com
- 📖 Documentação: https://docs.vizzionpay.com

---

**Desenvolvido com ❤️ usando React + Flask**

