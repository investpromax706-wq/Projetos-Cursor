import requests
import uuid
from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin

payment_bp = Blueprint('payment', __name__)

# Credenciais da API VizzionPay
VIZZION_PUBLIC_KEY = "luizaugustohetfeller_y389rh0u6458g7im"
VIZZION_SECRET_KEY = "qdzgq50prgtm6wotiruwr4ekqsuov4es48lm97byoz0ex48jxhavgv0g20l50z7r"
VIZZION_API_URL = "https://app.vizzionpay.com/api/v1/gateway/pix/receive"

@payment_bp.route('/create-pix-payment', methods=['POST'])
@cross_origin()
def create_pix_payment():
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        # Validar campos obrigatórios
        required_fields = ['name', 'email', 'phone', 'document', 'amount']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Gerar identificador único para a transação
        transaction_identifier = str(uuid.uuid4())
        
        # Preparar dados para a API VizzionPay
        payload = {
            "identifier": transaction_identifier,
            "amount": float(data['amount']),
            "shippingFee": 0,
            "extraFee": 0,
            "discount": 0,
            "client": {
                "name": data['name'],
                "email": data['email'],
                "phone": data['phone'],
                "document": data['document']
            },
            "products": [
                {
                    "id": "pagamento-5-centavos",
                    "name": "Pagamento de 5 centavos",
                    "quantity": 1,
                    "price": float(data['amount']),
                    "physical": False
                }
            ]
        }
        
        # Headers para autenticação
        headers = {
            'Content-Type': 'application/json',
            'x-public-key': VIZZION_PUBLIC_KEY,
            'x-secret-key': VIZZION_SECRET_KEY
        }
        
        # Fazer requisição para a API VizzionPay
        response = requests.post(VIZZION_API_URL, json=payload, headers=headers)
        
        if response.status_code == 201:
            api_data = response.json()
            return jsonify({
                'success': True,
                'transactionId': api_data.get('transactionId'),
                'status': api_data.get('status'),
                'pix': {
                    'code': api_data.get('pix', {}).get('code'),
                    'image': api_data.get('pix', {}).get('image'),
                    'base64': api_data.get('pix', {}).get('base64')
                },
                'order': api_data.get('order', {}),
                'fee': api_data.get('fee')
            }), 200
        else:
            error_data = response.json() if response.content else {}
            return jsonify({
                'error': 'Erro ao processar pagamento',
                'details': error_data.get('message', 'Erro desconhecido'),
                'statusCode': response.status_code
            }), 400
            
    except requests.exceptions.RequestException as e:
        return jsonify({
            'error': 'Erro de conexão com a API de pagamento',
            'details': str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'error': 'Erro interno do servidor',
            'details': str(e)
        }), 500

