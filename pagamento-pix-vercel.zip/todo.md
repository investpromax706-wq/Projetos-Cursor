## Tarefas para criar a página de pagamento de 5 centavos

- [ ] **Fase 1: Analisar documentação da API e tutorial**
  - [x] Ler `pasted_content.txt` (documentação da API)
  - [x] Ler `pasted_content_2.txt` (documentação de autenticação)
  - [x] Extrair informações relevantes da API (endpoints, métodos, parâmetros, autenticação)

- [x] **Fase 2: Desenvolver página de pagamento frontend**
  - [x] Criar um projeto React para a página de pagamento.
  - [x] Desenvolver o formulário de pagamento com campos para nome, email, telefone, CPF/CNPJ e valor (pré-preenchido com 0.05).
  - [x] Adicionar um botão para iniciar o pagamento.

- [x] **Fase 3: Implementar integração com API de pagamento**
  - [x] Criar um backend Flask para intermediar as requisições para a API VizzionPay.
  - [x] Configurar as credenciais da API (`x-public-key` e `x-secret-key`) no backend.
  - [x] Implementar a rota POST `/create-pix-payment` no backend que chama a API VizzionPay `/gateway/pix/receive`.
  - [x] Lidar com a resposta da API VizzionPay e retornar os dados do Pix (código copia e cola, imagem QR Code) para o frontend.

- [x] **Fase 4: Testar funcionalidade de pagamento**
  - [x] Iniciar o servidor Flask e o aplicativo React.
  - [x] Testar o fluxo de pagamento completo, desde o preenchimento do formulário até a exibição do QR Code/código Pix.
  - [x] Verificar se o valor de 5 centavos está sendo enviado corretamente.

- [x] **Fase 5: Entregar solução completa ao usuário**
  - [x] Fornecer instruções sobre como executar a aplicação.
  - [x] Entregar os arquivos do projeto (frontend e backend).



- [x] Extrair informações relevantes da API (endpoints, métodos, parâmetros, autenticação)


